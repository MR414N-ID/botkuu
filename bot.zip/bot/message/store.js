exports.dmff = (prefix) => {
return `
🦴ゝTUTUP
 ▬▬▭▬▬▭▬▬▭▬▬▭▬▬▭▬▬
␥50💎 : 7.400
␥70💎 : 9.600
␥140💎: 19.300
␥210💎 : 28.700
␥355💎 : 48.000
␥710💎 : 94.000
␥1000💎 : 129.000
␥1400💎 : 184.000
␥2000💎 : 249.000
ᗰᗰ : 28.900
ᗰᗷ : UPDATE.

𖥻 order : sabar
𖥻 ga sabar ga ush order, krn yg proses bukan aku gw cuma seller
- dm order di nomor :
🦴 𓄼 wa.me/6282292838634
`
}
exports.sewabot = (prefix) => {
return `
|I----𝐎𝐩𝐞𝐧 𝐒𝐞𝐰𝐚 𝐁𝐲 LANOX ----I| 

╭─═  ❃ 𝐹𝑖𝑡𝑢𝑟 𝐵𝑜𝑡𝑧 ❃  ═══
│❒ 𝑨𝒏𝒕𝒊𝒍𝒊𝒏𝒌
│❒ 𝑨𝒏𝒕𝒊𝒗𝒊𝒓𝒕𝒆𝒙
│❒ 𝑨𝒏𝒕𝒊𝒉𝒊𝒅𝒆𝒕𝒂𝒈
│❒ 𝑾𝒆𝒍𝒄𝒐𝒎𝒆
│❒ 𝑺𝒐𝒖𝒏𝒅 𝑴𝒆𝒏𝒖
│❒ 𝑺𝒕𝒊𝒄𝒌𝒆𝒓 𝑴𝒆𝒏𝒖
│❒ 𝑮𝒓𝒖𝒑 𝑴𝒆𝒏𝒖
│❒ 𝑮𝒂𝒎𝒆 𝑴𝒆𝒏𝒖
│❒ 𝑾𝒊𝒃𝒖 𝑴𝒆𝒏𝒖
│❒ 𝑰𝒏𝒇𝒐 𝑴𝒆𝒏𝒖
╰────────────┈ ⳹
╭回 𝐻𝑎𝑟𝑔𝑎 𝑆𝑒𝑤𝑎 回
│ 𝟏 𝑴𝒊𝒏𝒈𝒈𝒖 : 𝟏𝐊
│ 𝟏 𝑩𝒖𝒍𝒂𝒏 : 𝟓𝐊
│𝐩𝐞𝐫𝐦𝐚𝐧𝐞𝐧 𝐬𝐚𝐦𝐩𝐞 𝐨𝐰𝐧𝐞𝐫 𝐩𝐞𝐧𝐬𝐢 : 𝟏𝟓?
│𝐩𝐫𝐞𝐦𝐢𝐮𝐦 𝟏𝐛𝐮𝐥𝐚𝐧 : 𝟓𝐊
│𝐩𝐫𝐞𝐦𝐢𝐮𝐦 𝐦𝐚𝐧𝐞𝐧 : 𝟏𝟎𝐊
╰─────────┈ ⳹
╭回 𝑂𝑤𝑛𝑒𝑟 回
│https://wa.me/6282292838634
╰─────────┈ ⳹

[⚠️𝐼𝑛𝑓𝑜⚠️]
𝐩𝐞𝐫𝐦𝐚𝐧𝐞𝐧 𝐛𝐮𝐤𝐚𝐧 𝐚𝐦𝐩𝐞 𝐤𝐢𝐚𝐦𝐚𝐭 𝐚𝐧𝐣

_ALAN-BOTZ☕︎_
`
}
exports.follig = (prefix) => {
return `
OPEN SUNTIK FOLL IG BY ALAN

100 FOLL :1K
200 FOLL :2K
300 FOLL :3K
DST
MINAT CHAT
wa.me/6282292838634
`
}
exports.editing = (prefix) => {
return `
「JASA EDITING BY ALAN STORE」
*LOGO VEKTOR*

╭≽ *LOGO VEKTOR JB:2K*

*POSTER&DLL*

╭≽ *POSTER FT/FM:4K*
╭≽ *POSTER OPEN MEMBER:5K*
╭≽ *POSTER JEBOL SESI:5K*
╭≽ *POSTER LIST DM FF&ML:5K*
╭≽ *POSTER CR:5K*
╭≽ *EDIT SPEK JUAL AKUN:6K*
╭≽ *POSTER JOKI FF&ML:4K*
╭≽ *POSTER TRX ON:2K*
╭≽ *FRAME QRIS GOPAY/ALL PAY:3K*
╭≽ *BANNER YT:4K*
╭≽ *THUMBNAIL YT:5K*
╭≽ *POSTER LIST JASA DESIGN:4K*
╭≽ *POSTER FEE TRANSAKSI:3K*

*JASA EDITING VIDEO*

╭≽ *INTRO YOUTUBE 2D:8K*
╭≽ *JEDAG JEDUG BIASA:4K*
╭≽ *JEDAG JEDUG+SABER EFEK:10K*



PAYMENT
GOPAY/QRIS

SISTEM: PROSES LOGO/POSTER/VIDEO - TF - DONE

NOTE:JIKA UDH DI BUATIN LOGO SECEPAT NYA TF YA

RAGU? SKIP,TESTI? BARU OPEN BANG!

MINAT? CHAT NOMOR DI BAWAH INI!
http://wa.me/6282292838634
`
}
exports.culikmem = (prefix) => {
return `
JASA CULIK MEMBER BY ALAN STORE*

50MEM:2K
100MEM:5K
150MEM:7K
FULL:10K
Chat:wa.me/6282292838634
`
}
exports.pointft = (prefix) => {
return `
MAU OPEN FT TAPI KGK SEMPET NGITUNG POINT? TENANG SAYA SOLUSI NYA

*MENYEDIAKAN HITUNG POIN FT*
1M:1K
2M:2K
3M:3K
4M:4K
*OPEN JUGA SPECT+POINT TABLE*
1M:2K
2M:4K
3M:6K
4M:8K
*OPEN JASA BUAT CR JUGA DISINI!!!! *
1CR:2K
2CR:4K
3CR:6K
DST..... 

*OPEN JUGA BUAT POSTER FT CLASIC&CS
1POSTER:5K*

*SATU PAKET FT LENGKAP:POSTER+3CR+POINT TABLE+SPECT!!!!!*

*OPEN MURID HITUNG POINT OTOMATIS:5K SAHAJA*

MINAT? BISA CHAT:wa.me/6282292838634
©ALANSTORE
`
}
exports.muridbot = (prefix) => {
return `
OPEN MURID BUAT BOT STORE/JUALAN
BOT PRIBADI ADA 2 CARA BERBEDA BISA TAMBAHIN JUALAN KAMU!!!! 

BOT RESPONDER :
ANTILINK ×
TAMBAH JUALAN √
TAMBAH AUTO RESPON √
WELCOME ×
STICKER × 
CUMA NAMBAH PESAN TEXT
FREE DI BUATIN SC + APK PREMIUM
HARGA?? 3K

BOT TERMUX/HEROKU
ANTILINK √
WELCOME GG √
BROADCAST √
TAMBAHIN STORE √
STICKER √
TTP & ATTP √
HIDETAG √
DLL
FREE RECODE SC + RUN DI RDP NAMBAH 20K/BULAN
HARGA?? 10K

OPEN BUAT WEBSITE JASA SEWA BOT
HARGA?? 5K
CONTOH WEB:
https://dvlgaming.github.io/sewabot.github.io/

PAYMENT:GOPAY - QRIS /KETIK #payment

MINAT CHAT : wa.me/6282292838634
`
}
exports.webjualan= (prefix) => {
return `
*OPEN BUAT WEB JUALAN POLOS*
HARGA?? :5K
MURAH YA IYA 
BISA TAMBAHIN JUALAN MU CONTOH WEB NIH

https://dvlgaming.github.io/sewabot.github.io/

CUMA TAMBAHIN JUALAN+PAYMENT+NOMER SELLER
`
}
exports.crff = (prefix) => {
return `
per cr 1k jika stok
`
}
