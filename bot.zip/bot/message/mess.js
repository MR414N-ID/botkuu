module.exports.mess = {
	        wait: 'DALAM PROSES BRO MENDING FOLLOW IG GW DULU IG= _ LANOX _',
			success: 'NI HASILNYA KAK BANTU FOLLOW IG GW IG = _ LANOX _ ',
			wrongFormat: 'Format salah, coba liat lagi di menu',
			error: {
				api: 'APINYA HABIS BRO ISI ULANG DULU',
				stick: 'ITU BUKAN STIKER TOLOL',
				Iv: 'JANGAN NGASIH LINK GAJE TOD'
			},
			only: {
				group: 'KHUSUS GRUP BRO',
				admin: 'KHUSUS ADMIN GRUP BRO',
				premium: 'LU BUKAN MEMBER PREMIUM,BELI DULU SANA',
				owner: 'KHUSUS OWNER BRO',
				Badmin: 'BOT HARUS JADI ADMIN BRO',
			}
		}