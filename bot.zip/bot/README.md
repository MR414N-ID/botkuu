<div align="center">
<img src="https://i.ibb.co/R2jYFhc/442757cb859d28f896389b76fff1d758.gif" alt="DevilBotz" width="300" />

# DEVILBOTZ

>
>
>
</div>
<p align="center">
  <a href="https://instagram.com/devilstore19"><img src="https://img.shields.io/badge/Instagram-E4405F?style=for-the-badge&logo=instagram&logoColor=white"/> 
  <a href="https://wa.me/6288215463787"><img src="https://img.shields.io/badge/WhatsApp-25D366?style=for-the-badge&logo=whatsapp&logoColor=white" />
  <h4 align="center">
  <a href="https://YouTube.com/c/DEVILBOTZ>SUBSCRIBE MY YOUTUBE >//< </a>
</h4>
</p>

<p align="center">
<a href="#"><img title="DEVIL BOTZ" src="https://img.shields.io/badge/DEVILBOTZ-green?colorA=%23ff0000&colorB=%23017e40&style=for-the-badge"></a>
</p>
<p align="center">
<a href="https://github.com/DEVILBOTZ"><img title="Author" src="https://img.shields.io/badge/AUTHOR-DEVIL-orange.svg?style=for-the-badge&logo=github"></a>
</p>
<p align="center">
<a href="https://github.com/dvlgaming/devilbotzv5/watchers"><img title="Watchers" src="https://img.shields.io/github/watchers/dvlgaming/devilbotzv5?label=Watchers&color=green&style=flat-square"></a>
<a href="https://github.com/dvlgaming/devilbotzv5/stargazers"><img title="Stars" src="https://img.shields.io/github/stars/dvlgaming/devilbotzv5?label=Stars&color=yellow&style=flat-square"></a>
<a href="https://github.com/dvlgaming/devilbotzv5/graphs/contributors"><img title="Contributors" src="https://img.shields.io/github/contributors/dvlgaming/devilbotzv5?label=Contributors&color=blue&style=flat-square"></a>
<a href="https://github.com/dvlgaming/devilbotzv5/issues"><img title="Issues" src="https://img.shields.io/github/issues/dvlgaming/devilbotzv5?label=Issues&color=success&style=flat-square"></a>
<a href="https://github.com/dvlgaming/devilbotzv5/issues?q=is%3Aissue+is%3Aclosed"><img title="Issues" src="https://img.shields.io/github/issues-closed/dvlgaming/devilbotzv5?label=Issues&color=red&style=flat-square"></a>
<a href="https://github.com/dvlgaming/devilbotzv5/pulls"><img title="Pull Request" src="https://img.shields.io/github/issues-pr/dvlgaming/devilbotzv5?label=PullRequest&color=success&style=flat-square"></a>
<a href="https://github.com/dvlgaming/devilbotzv5/pulls?q=is%3Apr+is%3Aclosed"><img title="Pull Request" src="https://img.shields.io/github/issues-pr-closed/dvlgaming/devilbotzv5?label=PullRequest&color=red&style=flat-square"></a>
</p>
<img src="https://github.com/TheDudeThatCode/TheDudeThatCode/blob/master/Assets/Developer.gif" alt="Mario Game" width="600" />
<div align="center">
<details>
 
</details>

### 𝗧𝗵𝗮𝗻𝗸𝘀 TO DEVIL BOTZ

## Join Group Bot
[`Group Whatsapp`](https://chat.whatsapp.com/Fe9lr9fJMX4FY7BMkPSo5v)

-------
<h1 align="center">assalamu'alaikum <img src="https://user-images.githubusercontent.com/1303154/88677602-1635ba80-d120-11ea-84d8-d263ba5fc3c0.gif" width="40px" alt="hi"><br>I'm devil 😇 </h1>
<p align="center">
  <img src="https://c.top4top.io/p_2069qnvob1.jpg" /></>
</p>

- 👼 My name is rajif faishal Habibi 
- 🗣️ I am 13 years old 
- 🔭 I am not programmer

### FOR TERMUX USER
```bash
> pkg update && pkg upgrade
> pkg install git -y
> pkg install nodejs -y
> pkg install ffmpeg -y
> pkg install imagemagick -y
> git clone https://github.com/dvlgaming/devilbotzv5
> cd devilbotzv5
> npm install
```
###### Run
```bash
> npm start/node main.js
```

---------

### FOR WINDOWS/VPS/RDP USER
* Download And Install Git [`Click Here`](https://git-scm.com/downloads) <br>
* Download And Install NodeJS [`Click Here`](https://nodejs.org/en/download) <br>
* Download And Install FFMPEG [`Click Here`](https://ffmpeg.org/download.html) (don't forget to path) 
* Download And Install ImageMagick [`Click Here`](https://imagemagick.org/script/download.php) (if nulis want work,  checklist columns 1,2,3,5,6) 
```bash
> git clone https://github.com/dvlgaming/devilbotzv5
> cd devilbotzv5
> npm install
```
###### Run
```bash
> node index.js
```
--------------

## Tools

```bash
> Termux/web heroku juga bisa
> WhatsApp
> 2 HandPhone
```
## Mau deploy?
```
Ambil devil.json di termux & deploy seperti mendeploy rest api
Dan module harus lengkap biar bisa run otomatis

```
### WARNING
MAU RE-UPLOAD SCRIPT? KASIH NAMA/LINK CHANEL SAYA.... DILARANG UBAH INFO!!!

## NOTE:> 
SCRIPTNYA JANGAN DI JUAL/BELI KAN.. SCRIPT INI 100% GRATIS BUAT KALIAN PENGGUNA TERMUX
</div>

## DONASI <img src="https://github.com/TheDudeThatCode/TheDudeThatCode/blob/master/Assets/coin.gif" width="29px">
* [`Donasi DEVILBOTZ`](https://saweria.co/Dvlgaming)

## Note

* Dont Forget Stars

* |En| And You can add your own quotes
* |Ind| Dan Kalian Bisa tambahkan Quotes Kalian


## Special Thanks

* [Baileys](https://github.com/baileys)
* [devilbotz](https://github.com/dvlgaming)
* [dzz](https://github.com/DzWangy)
* [zak botz](https://github.com/)
* [akira](https://github.com/)
* [kurrxd](https://github.com/)


